package Ishahomes.framework;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;

import java.time.Duration;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Random;

public class IshaHomesAutomation {
 
    public static void main(String[] args) throws IOException, InterruptedException {

    	WebDriver driver = new ChromeDriver();
    	WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(25));
        Actions actions = new Actions(driver);
        try {
        	// Get into the website
            driver.get("https://ishahomes.com");
            driver.manage().window().maximize();
            driver.navigate().refresh();
            Thread.sleep(2000);

            // Handle the popup
            WebElement popupClose = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[6]/div[3]/div/div[1]/a/b")));
            popupClose.click();
            Thread.sleep(2000);
            WebElement popupClose1 = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("close-indicator")));
            popupClose1.click();
            Thread.sleep(1000);
            
            // Click the completed projects
            WebElement completedProjectsLink = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"menu-item-25810\"]/a")));
            completedProjectsLink.click();
            Thread.sleep(1000);
            
            // Scroll down the page
            JavascriptExecutor js=(JavascriptExecutor)driver;
            js.executeScript("window.scrollBy(0,300)"," ");
            Thread.sleep(1000);	
            
            WebElement all = wait.until(ExpectedConditions.elementToBeClickable(By.className("boosted-tabs-nav-icon")));
            all.click();
            Thread.sleep(5000);

            WebElement popupClose2 = wait.until(ExpectedConditions.presenceOfElementLocated(By.className("close-indicator")));
            popupClose2.click();
            
            // Find the size of completed projects
            List<WebElement> projects = driver.findElements(By.xpath("/html/body/main/div/section[2]/div/div/div/div/div/div/div/div[1]/div[1]/section/div/div/div/div/div/div/div/div"));
            System.out.println("Total projects found: " + projects.size());
            Thread.sleep(5000);
            
            // Printing the name of first five completed projects
            WebElement name=null;
            System.out.println("First five completed projects:");
            for (int i = 1; i <=5; i++) {
            	name = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\"module_properties\"]/div["+i+"]/div/div/div[2]/div/div[1]/div[1]/h2/a")));
                System.out.println(i + "." +name.getText());
            }
            Thread.sleep(2000);
            
            // After Scrolling click enquireNow button
            WebElement enquireNowBtn =wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Enquire Now")));
            actions.moveToElement(enquireNowBtn).click().perform();
            Thread.sleep(2000);
           
            // Check if the contact info is dispalyed
            WebElement contactInfo = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[normalize-space()='Call']")));
            System.out.println("Contact Info section is displayed: " + contactInfo.isDisplayed());
            Thread.sleep(2000);
            
            // Read the email address
            WebElement email=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[normalize-space()='Other Enquiry']")));
            email.click();
            
            // Extract and print email address
            
            WebElement emailElement = driver.findElement(By.xpath("//a[normalize-space()='marketing@ishahomes.com']"));
            System.out.println("Contact Email: " + emailElement.getText());
            Thread.sleep(2000);
            
            // Take a screenshot
     
            TakesScreenshot ts = ((TakesScreenshot)driver);
            File src=ts.getScreenshotAs(OutputType.FILE);
          
            String directory= "C:\\Users\\2401132\\eclipse-workspace\\projects\\screenshots\\";
    		File obj= new File(directory);
    		File[] files= obj.listFiles();
    		Random ran= new Random();
    		String srce= "img"+Integer.toString(ran.nextInt(1000))+".png";
    		if(files.length==0) {
    			src.renameTo(new File("C:\\Users\\2401132\\eclipse-workspace\\projects\\screenshots\\"+srce));
    		}
    		for(File filename:files) {
    			srce= "img"+Integer.toString(ran.nextInt(1000))+".png";
    			if(!filename.equals(srce)) {
    				src.renameTo(new File("C:\\Users\\2401132\\eclipse-workspace\\projects\\screenshots\\"+srce));
    				break;
    			}
    		}
    		System.out.println("Screenshot captured successfully");
            } catch (Exception e) {
            e.printStackTrace();
            } 
              finally {
               driver.quit();
            }
       }

}
 