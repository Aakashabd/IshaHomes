package Ishahomes.framework.utils;

import org.openqa.selenium.*;
import java.io.File;
import java.util.Random;

public class ScreenshotUtil {
    public static void takeScreenshot(WebDriver driver, String directory) {
        try {
            TakesScreenshot ts = (TakesScreenshot) driver;
            File src = ts.getScreenshotAs(OutputType.FILE);
            File obj = new File(directory);
            File[] files = obj.listFiles();
            Random rand = new Random();
            String srce = "img" + rand.nextInt(1000) + ".png";

            if (files.length == 0) {
                src.renameTo(new File(directory + srce));
            } else {
                for (File filename : files) {
                    srce = "img" + rand.nextInt(1000) + ".png";
                    if (!filename.getName().equals(srce)) {
                        src.renameTo(new File(directory + srce));
                        break;
                    }
                }
            }
            System.out.println("Screenshot captured successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
