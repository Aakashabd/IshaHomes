package Ishahomes.framework.tests;

import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import Ishahomes.framework.pages.HomePage;
import Ishahomes.framework.pages.CompletedProjectsPage;
import Ishahomes.framework.utils.ScreenshotUtil;

import Ishahomes.framework.base.BaseTest;

public class IshaHomesTest extends BaseTest {

    @Test
    public void testCompletedProjectsFlow() throws InterruptedException {
        setUp();
        Actions actions = new Actions(driver);

        HomePage home = new HomePage(driver, wait);
        CompletedProjectsPage completed = new CompletedProjectsPage(driver, wait);

        home.openHomePage();
        home.closePopups();
        home.goToCompletedProjects();

        completed.clickAllTab();
        completed.printProjectNames();
        completed.clickEnquireNow(actions);
        completed.printContactInfo();

        ScreenshotUtil.takeScreenshot(driver, "C:\\Users\\2401132\\eclipse-workspace\\framework\\src\\test\\resource\\screenshots\\");
        tearDown();
    }
}

