package Ishahomes.framework.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;
import java.util.List;

public class CompletedProjectsPage {
    WebDriver driver;
    WebDriverWait wait;

    @FindBy(className = "boosted-tabs-nav-icon")
    WebElement allTab;

    @FindBy(className = "close-indicator")
    WebElement popupClose2;

    @FindBy(xpath = "/html/body/main/div/section[2]/div/div/div/div/div/div/div/div[1]/div[1]/section/div/div/div/div/div/div/div/div")
    List<WebElement> projects;

    @FindBy(linkText = "Enquire Now")
    WebElement enquireNowBtn;

    @FindBy(xpath = "//a[normalize-space()='Call']")
    WebElement contactInfo;

    @FindBy(xpath = "//span[normalize-space()='Other Enquiry']")
    WebElement otherEnquiry;

    @FindBy(xpath = "//a[normalize-space()='marketing@ishahomes.com']")
    WebElement emailElement;

    public CompletedProjectsPage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
        PageFactory.initElements(driver, this);
    }

    public void clickAllTab() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(allTab)).click();
        Thread.sleep(5000);
        wait.until(ExpectedConditions.elementToBeClickable(popupClose2)).click();
    }

    public void printProjectNames() throws InterruptedException {
    	
        System.out.println("Total projects found: " + projects.size());
        Thread.sleep(2000);
        System.out.println("First five completed projects:");
        for (int i = 0; i < Math.min(5, projects.size()); i++) {
            WebElement name = projects.get(i).findElement(By.tagName("h2"));
            System.out.println((i + 1) + ". " + name.getText());
        }
    }

    public void clickEnquireNow(Actions actions) throws InterruptedException {
        actions.moveToElement(enquireNowBtn).click().perform();
        Thread.sleep(2000);
    }

    public void printContactInfo() throws InterruptedException {
        System.out.println("Contact Info section is displayed: " + contactInfo.isDisplayed());
        Thread.sleep(2000);
        otherEnquiry.click();
        Thread.sleep(2000);
        System.out.println("Contact Email: " + emailElement.getText());
    }
}

