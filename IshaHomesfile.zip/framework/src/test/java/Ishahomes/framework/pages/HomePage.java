package Ishahomes.framework.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.*;

public class HomePage {
    WebDriver driver;
    WebDriverWait wait;

    @FindBy(xpath = "/html/body/div[6]/div[3]/div/div[1]/a/b")
    WebElement popupClose;

    @FindBy(className = "close-indicator")
    WebElement popupClose1;

    @FindBy(xpath = "/html/body/main/header/div[1]/div/div/div/nav/ul/li[5]/a")
    WebElement completedProjectsLink;

    public HomePage(WebDriver driver, WebDriverWait wait) {
        this.driver = driver;
        this.wait = wait;
        PageFactory.initElements(driver, this);
    }
    public void openHomePage() throws InterruptedException {
        driver.get("https://ishahomes.com");
        driver.navigate().refresh();
        Thread.sleep(2000);
    }
    public void closePopups() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(popupClose)).click();
        Thread.sleep(2000);
        wait.until(ExpectedConditions.elementToBeClickable(popupClose1)).click();
        Thread.sleep(1000);
    }
    public void goToCompletedProjects() throws InterruptedException {
        wait.until(ExpectedConditions.elementToBeClickable(completedProjectsLink)).click();
        Thread.sleep(2000);
    }
}







